# SPIR Token Site

This is the official multi-page React + Tailwind site for SPIR token.

## Pages

- Home: Overview + Buy Button
- White Pages: Philosophy
- About: Project background
- Dashboard: Token and wallet tools

## Getting Started

1. Clone or upload to GitHub
2. Run:

```bash
npm install
npm run dev
```

3. Visit http://localhost:3000