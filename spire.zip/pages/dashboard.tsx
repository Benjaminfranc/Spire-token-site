export default function Dashboard() {
  return (
    <div className="py-10 px-4">
      <h1 className="text-3xl font-bold mb-4">Dashboard</h1>
      <p className="text-purple-200">Track your wallet, SPIR balance, and glyph state here soon.</p>
    </div>
  );
}